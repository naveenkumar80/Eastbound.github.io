<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Services</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<aside id="sticky-social">
    <ul>
        <li>
            <a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank">
                <i class="fa fa-linkedin" aria-hidden="true">
                </i>
            </a>
        </li>
        <li>
            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank">
                <i class="fa fa-facebook" aria-hidden="true">
                </i>
            </a>
        </li>
        <li>
            <a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank">
                <i class="fa fa-instagram" aria-hidden="true">
                </i>
            </a>
        </li>
  </ul>
</aside>
    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>    <!-- ./HEADER -->
    <!-- SLIDE -->
    <div class="clearfix"></div>
    <!-- /SLIDE --> 
	<div class="section-about margin-top-100">
		<div class="container">
			<div class="about-text text-center">
				<h1 class=" black-heading1">EB Experiential Travel</h1>
                    <p style="max-width:930px; margin:auto;">Established by a group of highly respected travel professionals, EB is defined by its passion and commitment to create unparalleled journeys of discovery…of people, cultures, history, food, wellness and the spiritual, that translate into timeless stories.<br>
Eastbound lives through its deep-rooted network with ‘local owners of the heritage’ to deliver on this promise.</p>
			</div>
		</div>
	</div>
    
    
   
   
   <div class="section-portfolio2">
        <div class="bz-portfolio">
            <div class="bz-popup-gallery portfolio-grid portfolio-style2 pf-hover1" data-cols="3" data-layoutMode="fitRows">
                <div class="item-portfolio">
                  <a href="discovery-trips.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/dt.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1">Discovery Trips</h3>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="col-md-12 padding20 service-ryt-padding">
                    <p>	Discover yourself, the world, your passion; with EB. Whether its photography, food, cycling or just walking that makes you happy – we have the itinerary that will put a new meaning to the word ‘discovery’. Tell us what you love and we can customize a trip according to it, and help you discover your inner traveller.</p><br> 
                    <a href="discovery-trips.php" target="_blank" class="pf-icon1 zoom">
                        <i class="fa fa-plus">
                        </i>
                    </a>
                </div>
            </div>

            <div class="item-portfolio">
                <a href="adventure.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/oe.png" style="width:100%;" alt="">
                        </div>
                      <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1">Outdoor Experience</h3>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="col-md-12 padding20 service-ryt-padding">
                    <p>The extravagant experiences that make you explore the countryside assiduously. When it comes to theory, we all love adventure to its wildest, but in reality we want our adventure to be deranged to be fun but resilient enough to be comfortable. We at Eastbound Outdoors, curate and cautiously handpick programs, designed especially for you, to witness the city’s most scenic attractions without accessing them roughly.</p><br> 
                    <a href="discovery-trips.php" target="_blank" class="pf-icon1 zoom">
                        <i class="fa fa-plus">
                        </i>
                    </a>
                </div>
            </div>

            <div class="item-portfolio">
                <a href="luxury-cruises.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/ls.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1">Luxury Cruises</h3>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="col-md-12 padding20 service-ryt-padding">
                    <p>	Our signature touch extends seamlessly to luxury cruises around the Indian sub-continent, UAE, Maldives and Seychelles. We create amazing journeys, including overland tours, a wide plethora of discovery trips, anything you could desire or imagine to complete your experience, and we seamlessly facilitate everything to fulfill a cruise travelers dream!  </p> 
                    <a href="luxury-cruises.php" target="_blank" class="pf-icon1 zoom">
                        <i class="fa fa-plus">
                        </i>
                    </a>
                </div>
            </div>

            <div class="item-portfolio">
                <a href="photography-tours.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/pt.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1">Photography tours</h3>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="col-md-12 padding20 service-ryt-padding">
                    <p>Abhishek Hajela is a ‘Nikon International Photography Award Winner’, National Photojournalist, Blogger and a well-experienced travel escort based in New Delhi. He leads and curates our Photography Tours and specialized experiential travel itineraries across India, Bhutan, Nepal and Sri Lanka’s culture, festivals, people, villages; and the sheer plethora of experiences that the region offers. </p>
                    <a href="photography-tours.php" target="_blank" class="pf-icon1 zoom">
                        <i class="fa fa-plus">
                        </i>
                    </a>
                </div>
            </div>

            <div class="item-portfolio">
                <a href="educational-tours.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/et.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1">Educational Travel</h3>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="col-md-12 padding20 service-ryt-padding">
                    <p>Go beyond a brick and mortar educational institute and learn through the best teacher of all – travel. We take you on journeys that will teach you like no regular classroom can. With our authentic grassroots experiences and engaging activities, students imbibe cultures, history and much more to become more well-rounded individuals and contribute productively to society.  </p>
                    <a href="educational-tours.php" target="_blank" class="pf-icon1 zoom">
                        <i class="fa fa-plus">
                        </i>
                    </a>
                </div>
            </div>
			
				
				<!--<div class="item-portfolio">
                 <a href="#">   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/7.jpg" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1">MICE & Events</h3>
                            </div>
                        </div>
                    </div></a>
                    <div class="col-md-12 padding20 service-ryt-padding">
                        	<p>With a strong track-record of precision project management and exceptional client outcomes, our event architects are specialists in their craft, working collaboratively to design solutions tailored to your individual needs. Within our full-service event management company, we have specialist expertise across conference and association management, conference design, planning and outstanding delivery, and much more. </p>
                             <a href="#" class="pf-icon1 zoom"><i class="fa fa-plus"></i></a>
                            </div>
                </div>
				
				<div class="item-portfolio">
                 <a href="#">   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/11.jpg" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1">Bespoke Travel</h3>
                            </div>
                        </div>
                    </div></a>
                    <div class="col-md-12 padding20 service-ryt-padding">
                        	<p>With Eastbound, you have the luxury of customizing your trips from A to Z. We design your travel experience with the help of our insightful squad which gets intimately involved with the microscopic detailing of your trip, making sure that you enjoy the wind, sip margaritas and treat your belly with finger-licking delicacies and not worry about the hotel bookings. Sit back and relax while we prepare your itinerary including – accommodation, transport, trip length, activities, places of interest, and pace of travel. </p>
                             <a href="#" class="pf-icon1 zoom"><i class="fa fa-plus"></i></a>                            </div>
                </div>-->
				
				<div class="item-portfolio">
                    <a href="csr.php">
                        <div class="pf-caption">
                            <div class="pf-image">
                                <img src="images/services/9.jpg" style="width:100%;" alt="">
                            </div>
                            <div class="pf-info text-center">
                                <div class="pf-content-info">    
                                    <h3 class="white-heading1">Vouluntourism</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                    <div class="col-md-12 padding20 service-ryt-padding">
                        <p>With changing times our society has shown need for care, which has led to the birth of – Voluntourism or Volunteer Tourism. If you get teary-eyed seeing the malnutrition kids, the frail dogs or the decaying nature, pack your bags and indulge into the humanizing escapade of Voluntourism. Travelling to ease-off is great but travelling for a purpose and for social good is even better. We allow the travellers to explore a place through one’s heart. And to best showcase it all, each of our tours are based on principles of – Responsible Tourism, Social Consciousness, Environmental concerns, out of the box experiences, Unique Cultural interactions and more.</p>
                        <a href="#" class="pf-icon1 zoom">
                            <i class="fa fa-plus">
                            </i>
                        </a>
                    </div>
                </div>
				
				<!--<div class="item-portfolio">
                <a href="#">   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/12.jpg" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1">Sports</h3>
                            </div>
                        </div>
                    </div></a>
                    <div class="col-md-12 padding20 service-ryt-padding">
                        	<p>With a mission to revolutionize sports at the grassroots level in India, Eastbound takes you on a program that is aimed at popularizing sports among youngsters by giving them opportunities to play with international and national stars. From high-level coach interaction and meetings & consultations to visiting players, Eastbound strives to give you a 360 degree view of the sports culture in India. </p>
                             <a href="#" class="pf-icon1 zoom"><i class="fa fa-plus"></i></a>
                            </div>
                </div>-->
				
                
                
                
            </div>
        </div>
    </div>
   
   <div class="base1"  style="height:300px;"></div>
   <div class="section-about" style="margin-top:-300px;">
		<div class="container">
			<div class="about-text text-center" style="padding-top:50px;">
			
				<h1 class="black-heading1">Our Services</h1>
               
				
               <div class="testimonials testimonials-style2">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="testimonial">
                            <div class="avatar">
                                <img src="images/home-testi.jpg" alt="" />
                            </div>
                            
                        </div>
                    </div>
                   
                </div>
            </div>
                
				<p class="services-text">Handcrafting Special Journeys  &nbsp; <span class="service-bar">| </span>  &nbsp; Private Jets, Cruises & Charter services<br>
Elite panel of Experts, Guides and Imminent Personalities&nbsp; <span class="service-bar"> | </span> &nbsp; MICE & Events<br>
Luxury, Boutique & Designer hotels  &nbsp; <span class="service-bar"> | </span> &nbsp; Private Villas to Homestays<br>
Ultra luxury and modern fleet of cars and family wagons<br>
Personalized Concierge services  &nbsp; <span class="service-bar"> | </span> &nbsp;  24 x7 Guest Relationship Managers
 </p>
			</div>
		</div>
	</div>
   
   
   
	
    
    <!-- FOOTER -->
    <footer class="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank">
                                <i class="fa fa-facebook footer-social">
                                </i>
                            </a>
                            <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank">
                                <i class="fa fa-google-plus footer-social" aria-hidden="true">
                                </i>
                            </a>
                            <a href="csr.php" target="_blank">
                                <i class="fa fa-heart footer-social" aria-hidden="true">
                                </i>
                            </a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>
</html>