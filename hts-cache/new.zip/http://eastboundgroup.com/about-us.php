<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | About Us</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
     <link rel="stylesheet" type="text/css" href="css/about-slider.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>

<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>

    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    
    	<div class="margin-top-100">
    <div class="main-container">
        <div class="container">
            <div class="col-sm-7 col-md-7 main-content">
                <div class="w3-content w3-display-container">

<a class="w3-btn-floating w3-hover-dark-grey w3-display-left" onClick="plusDivs(-1)">&#10094;</a>
<a class="w3-btn-floating w3-hover-dark-grey w3-display-right" onClick="plusDivs(1)">&#10095;</a>

<div class="w3-display-container mySlides">
  <img src="images/about-us/1.jpg" style="width:100%">
  <!--<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Our guests are busy clicking the Elephant on his daily round <br> © Eastbound Group
  </div>-->
</div>

<div class="w3-display-container mySlides">
  <img src="images/about-us/3.jpg" style="width:100%">
  <!--<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Young monks walk down to the Holy River Ganges to perform the Morning Prayer <br> © Eastbound Group
  </div>-->
</div>

<div class="w3-display-container mySlides">
  <img src="images/about-us/4.jpg" style="width:100%">
  <!--<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Young monks walk down to the Holy River Ganges to perform the Morning Prayer <br> © Eastbound Group
  </div>-->
</div>
<div class="w3-display-container mySlides">
  <img src="images/about-us/5.jpg" style="width:100%">
  <!--<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Young monks walk down to the Holy River Ganges to perform the Morning Prayer <br> © Eastbound Group
  </div>-->
</div>
<div class="w3-display-container mySlides">
  <img src="images/about-us/6.jpg" style="width:100%">
 <!--<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
   Our guests are served with breakfast at a Buddhist monastery in Leh, Ladakh. <br> © Eastbound Group
  </div>--></div>

</div>
            </div>
            <div class="col-sm-5 col-md-5 sidebar blog-slidebar">
            	<div class="widget widget_about_me">
            			 <h4 class="horizontal-line1">About Us</h4>
			        <div class="service-text">
	            			<p>Established by a group of highly respected travel professionals who are driven by a passion to innovate, enhance and create deep rooted travel experiences, EB, is today one of the leading full service destination management companies in the sub-continent and the UAE.</p>
 <p>We specialise in India, UAE, Nepal, Bhutan and Sri Lanka and are experienced in delivering high quality of service in the challenging environs of the Indian sub-continent. With affiliations across the globe and some of the best ground handling agencies as partners.  </p>
  <p>We are able to provide the benefits of a pool of resources that includes a globally tuned professional management, backed by a dedicated, proactive team, financial stability and buying power, the latest in technology - all geared towards delivering a highly value added experience. </p>
<p>With representative offices in the USA, UK, Italy, France, Russia, South America and Germany, EB has a well established global alliance with some of the finest travel companies across the globe.</p>
	              </div>
		            </div>
                      </div>
                        </div>
        </div>
    </div>
    
    
    <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel,4000); // Change image every 2 seconds
}
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block"; 
}
</script>
    <!-- /SLIDE --> 

   
   
   <div class="section-feature-3 base5">
        <div class="container">
            
            <div class="row">
                <div class="col-sm-4">
                  <h3 class="horizontal-line black-heading margin-top-100">The EB Advantage</h3>
                  
                  <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading"> A fully empowered and experienced team on ground</p></span>
                    </div>
                    
                     <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading"> Excellent buying capacity with group diversity</p></span>
                    </div>
                    
                       <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading">Specialized Product and Experiences</p></span>
                    </div>
                    
                     <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading">Unmatched quality control</p></span>
                    </div>
                  
                     <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading">Global presence with dedicated Offices and Sales resource</p></span>
                    </div>
                    
                      <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading">Technology driven</p></span>
                    </div>
                  
                    
                    
                  
                </div>
                <div class="col-sm-4 text-center">
                    <img src="images/about-us/ab.png" class="img-responsive" alt="">
                </div>
                <div class="col-sm-4">
                <h3 class="horizontal-line black-heading margin-top-100">The EB Assurance and Philosophy</h3>
                
                
                <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading"> Provide on-site services that are the best available in the market, with no compromise on service standards</p></span>
                    </div>
                    
                     <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading"> Deliver levels of service that exceed our clients’ expectations</p></span>
                    </div>
                
                    
                    
                    <div>
                    <span class="col-md-1 col-xs-1 no-padding">
                         <img src="images/about-us/about-icon.png"/></span>
                      <span class="col-md-11 col-xs-11 no-padding">
                        <p class="blue-heading"> Ensure the company’s products and services conserve the integrity of the environment, respect the cultural heritage of the community and utilize<br> locally-sourced components, thereby contributing to the community-at-large.</p></span>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
	
    
    
    
    
    
    
    <!-- FOOTER -->
    <footer class="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                       <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>